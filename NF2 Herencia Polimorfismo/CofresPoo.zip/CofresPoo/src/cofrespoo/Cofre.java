/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package cofrespoo;

import java.util.ArrayList;

/**
 *
 * @author mati
 */
public abstract class Cofre {
    protected int monedas;
    ArrayList<Carta> salen;
    ArrayList<Carta> disponibles;

    public Cofre() {
        //inicializar variables que no son primitivas
        salen = new ArrayList<>();
        disponibles = new ArrayList<>();
        cargar_disponibles();
        
    }
    
    
    
    public void mostrar_cofre()
    {
        System.out.println("Monedas del cofre" + monedas);
        System.out.println("te han tocado...");
        for (int i = 0; i < salen.size(); i++) {
            System.out.println(salen.get(i).toString());
        }
        System.out.println("Las disponibles eran");
        for (int i = 0; i < disponibles.size(); i++) {
            System.out.println(disponibles.get(i).toString());
        }
        
        
        
        
        
    }
    
    
    
    

    
    private void cargar_disponibles() {
        Carta nueva = new Carta("Pekka", 7, Tipo_carta.EPICA);
        disponibles.add(nueva);
        nueva = new Carta("Mini Pekka", 4, Tipo_carta.RARA);
        disponibles.add(nueva);
        nueva = new Carta("Leñador", 4, Tipo_carta.LEGENDARIA);
        disponibles.add(nueva);
        
        
        
        
        
    }
    
    
    
}
